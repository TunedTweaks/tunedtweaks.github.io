﻿<#
  TUNED. - Stage 2 Full Tune Pack (v2.3)
  Windows + Fortnite-specific optimization script

  RUN THIS VIA TUNED.bat, NOT by double-clicking this .ps1 file directly.
  Windows never runs .ps1 files from a double-click (it tries to open them in a text
  editor instead) - TUNED.bat is the one buyers should actually click.

  WHAT'S NEW IN v2.3:
    - Finds Fortnite's real install folder using Epic's own launcher manifest data,
      instead of guessing common folder names (fixes it not finding Fortnite on
      custom install drives/locations).
    - Undo is now built into TUNED.bat itself (option 2 in its menu) once this has
      been run once - no separate undo file to keep track of.

  WHAT'S NEW IN v2.2:
    Every change this script makes is captured with its ORIGINAL value before it's
    changed, and a matching tuned-undo.ps1 is generated at the end that reverses every
    single tweak precisely - not just a generic "hope System Restore is turned on" net.

  WHAT THIS DOES (every change is visible in normal Windows Settings/Task Manager -
  nothing here touches game files, memory, or anything Epic could flag as third-party software):
    1. Creates a System Restore point (extra safety net, on top of the undo script below).
    2. Sets the power plan to Ultimate Performance (or High Performance as fallback).
    3. Enables Hardware-Accelerated GPU Scheduling.
    4. Disables Fullscreen Optimizations for Fortnite specifically.
    5. Stops Windows from powering down your network adapter to save power.
    6. Disables Xbox Game Bar + background game recording.
    7. Reduces the NVIDIA and Discord in-game overlay footprint (known frame-time cost).
    8. Applies the low-latency TCP tweak (disables Nagle's algorithm) on your active network adapter.
    9. Tells Windows' multimedia scheduler to treat Fortnite as a "Games" task with high GPU/CPU
       priority, and removes the network throttling limit multimedia apps normally get capped by.
    10. Turns off Windows Delivery Optimization's peer-to-peer uploading.
    11. Sets FortniteClient-Win64-Shipping.exe to High process priority automatically at launch
        (via a lightweight scheduled task).
    12. Checks whether RAM is running at its rated speed (XMP/DOCP) and tells you if it isn't.
    13. Writes a personal tune report (tuned-report.txt) and an undo script (tuned-undo.ps1).

  WHAT THIS WON'T DO: guarantee a specific FPS number. Actual results depend entirely on your
  hardware and what's already configured. This script applies every reasonable OS/process-level
  tweak; it can't manufacture GPU headroom that isn't there.

  TO UNDO EVERYTHING LATER: run TUNED.bat again - it detects tuned-undo.ps1 next to it and
  offers an undo option. That reverses every change this script made, specifically and in full.
#>

#Requires -RunAsAdministrator

$scriptVersion = "2.3"
$startTime = Get-Date
$changes = New-Object System.Collections.Generic.List[string]
$skipped = New-Object System.Collections.Generic.List[string]
$undoLines = New-Object System.Collections.Generic.List[string]
$logPath = Join-Path $PSScriptRoot "tuned-tune-log.txt"
Start-Transcript -Path $logPath -Append | Out-Null

Write-Host "== TUNED. Full Tune Pack (v$scriptVersion) ==" -ForegroundColor Yellow
Write-Host "Applying tweaks to your system - this takes under a minute. Don't close this window.`n"

# Generic helper: reads a registry value's CURRENT state, records how to restore it,
# then sets the new value. This is what makes tuned-undo.ps1 exact rather than a guess.
function Set-TunedRegValue {
    param(
        [string]$Path,
        [string]$Name,
        $Value,
        [string]$Type = "DWord"
    )
    New-Item -Path $Path -Force -ErrorAction SilentlyContinue | Out-Null
    $existing = Get-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue
    if ($null -ne $existing) {
        $oldValue = $existing.$Name
        $undoLines.Add("Set-ItemProperty -Path '$Path' -Name '$Name' -Value '$oldValue' -Type $Type -ErrorAction SilentlyContinue")
    } else {
        $undoLines.Add("Remove-ItemProperty -Path '$Path' -Name '$Name' -ErrorAction SilentlyContinue")
    }
    Set-ItemProperty -Path $Path -Name $Name -Value $Value -Type $Type
}

# Finds Fortnite's actual .exe by reading Epic Games Launcher's own install manifests
# first (accurate regardless of which drive/folder it was installed to), falling back
# to a brute-force search of common folders if the manifest lookup finds nothing.
function Find-FortniteExe {
    try {
        $manifestDir = Join-Path $env:ProgramData "Epic\EpicGamesLauncher\Data\Manifests"
        if (Test-Path $manifestDir) {
            $manifestFiles = Get-ChildItem -Path $manifestDir -Filter "*.item" -ErrorAction SilentlyContinue
            foreach ($mf in $manifestFiles) {
                try {
                    $data = Get-Content $mf.FullName -Raw | ConvertFrom-Json
                    if ($data.DisplayName -like "*Fortnite*" -or $data.AppName -like "*Fortnite*") {
                        $candidate = Join-Path $data.InstallLocation "FortniteGame\Binaries\Win64\FortniteClient-Win64-Shipping.exe"
                        if (Test-Path $candidate) { return $candidate }
                    }
                } catch { }
            }
        }
    } catch { }

    # Fallback: check the common default install locations across likely drives
    $fallbackRoots = @()
    foreach ($drive in (Get-PSDrive -PSProvider FileSystem)) {
        $fallbackRoots += "$($drive.Root)Epic Games\Fortnite\FortniteGame\Binaries\Win64"
    }
    $fallbackRoots += "$env:LOCALAPPDATA\FortniteGame\Binaries\Win64"
    foreach ($root in $fallbackRoots) {
        $candidate = Join-Path $root "FortniteClient-Win64-Shipping.exe"
        if (Test-Path $candidate) { return $candidate }
    }
    return $null
}

# 1. System Restore point (extra safety net alongside the precise undo script below)
try {
    Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction SilentlyContinue
    Checkpoint-Computer -Description "TUNED - before Fortnite tune" -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop
    $changes.Add("Created a System Restore point ('TUNED - before Fortnite tune')")
} catch {
    Write-Host "Could not create a restore point (often disabled by default, or one was made recently) - the undo script below still covers you." -ForegroundColor DarkYellow
}

# 2. Power plan: try Ultimate Performance first, fall back to High Performance
try {
    $originalScheme = (powercfg -getactivescheme) -replace '.*GUID: ([0-9a-f\-]{36}).*', '$1'
    if ($originalScheme) {
        $undoLines.Add("powercfg -setactive $originalScheme")
    }
    $ultimateGuid = "e9a42b02-d5df-448d-aa00-03f14749eb61"
    $dupOutput = powercfg -duplicatescheme $ultimateGuid 2>&1
    $newGuid = ($dupOutput | Select-String -Pattern '([0-9a-f\-]{36})').Matches.Value | Select-Object -Last 1
    if ($newGuid) {
        powercfg -setactive $newGuid
        $changes.Add("Enabled and activated the Ultimate Performance power plan")
    } else {
        throw "Ultimate Performance not available on this edition"
    }
} catch {
    try {
        $highPerf = powercfg -l | Select-String "High performance"
        if ($highPerf) {
            $guid = ($highPerf -split '\s+')[3]
            powercfg -setactive $guid
        } else {
            powercfg -duplicatescheme 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c | Out-Null
            powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
        }
        $changes.Add("Set power plan to High Performance (Ultimate Performance isn't available on this Windows edition)")
    } catch {
        Write-Host "Skipped power plan change: $_" -ForegroundColor DarkYellow
        $skipped.Add("Power plan change")
    }
}

# 2b. Enable Hardware-Accelerated GPU Scheduling (needs a restart to take effect)
try {
    Set-TunedRegValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" -Name "HwSchMode" -Value 2 -Type DWord
    $changes.Add("Enabled Hardware-Accelerated GPU Scheduling (takes effect after restart)")
} catch {
    Write-Host "Skipped GPU scheduling change: $_" -ForegroundColor DarkYellow
    $skipped.Add("Hardware-Accelerated GPU Scheduling")
}

# 2c. Disable Fullscreen Optimizations specifically for Fortnite
try {
    $fnExePath = Find-FortniteExe
    if ($fnExePath) {
        Set-TunedRegValue -Path "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers" -Name $fnExePath -Value "~ DISABLEDXMAXIMIZEDWINDOWEDMODE" -Type String
        $changes.Add("Disabled Fullscreen Optimizations for Fortnite (found at $fnExePath)")
    } else {
        $changes.Add("Couldn't locate the Fortnite executable automatically - disable Fullscreen Optimizations manually via the .exe's Properties > Compatibility tab if you want this one")
        $skipped.Add("Fullscreen Optimizations disable (Fortnite not found)")
    }
} catch {
    Write-Host "Skipped Fullscreen Optimizations change: $_" -ForegroundColor DarkYellow
    $skipped.Add("Fullscreen Optimizations disable")
}

# 2d. Stop the network adapter from being allowed to power itself down
try {
    Get-NetAdapter | Where-Object { $_.Status -eq "Up" } | ForEach-Object {
        $adapterName = $_.Name
        $pnpDevice = Get-PnpDevice -FriendlyName $_.InterfaceDescription -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($pnpDevice) {
            $powerMgmt = Get-CimInstance -Namespace root\wmi -ClassName MSPower_DeviceEnable -ErrorAction SilentlyContinue |
                Where-Object { $_.InstanceName -like "*$($pnpDevice.InstanceId)*" }
            if ($powerMgmt) {
                $wasEnabled = $powerMgmt.Enable
                $instanceName = $powerMgmt.InstanceName
                $powerMgmt.Enable = $false
                Set-CimInstance -InputObject $powerMgmt -ErrorAction SilentlyContinue
                $changes.Add("Stopped Windows from powering down the '$adapterName' network adapter to save power")
                $undoLines.Add("Get-CimInstance -Namespace root\wmi -ClassName MSPower_DeviceEnable | Where-Object { `$_.InstanceName -eq '$instanceName' } | ForEach-Object { `$_.Enable = `$$wasEnabled; Set-CimInstance -InputObject `$_ }")
            }
        }
    }
} catch {
    Write-Host "Skipped NIC power-saving change: $_" -ForegroundColor DarkYellow
    $skipped.Add("Network adapter power-saving disable")
}

# 3. Disable Xbox Game Bar + background recording
try {
    Set-TunedRegValue -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR" -Name "AppCaptureEnabled" -Value 0 -Type DWord
    Set-TunedRegValue -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_Enabled" -Value 0 -Type DWord
    $changes.Add("Disabled Xbox Game Bar background recording")
} catch {
    Write-Host "Skipped Game Bar change: $_" -ForegroundColor DarkYellow
    $skipped.Add("Xbox Game Bar disable")
}

# 4. Disable overlays known to cost frame time
try {
    if (Test-Path "HKCU:\SOFTWARE\NVIDIA Corporation") {
        Set-TunedRegValue -Path "HKCU:\SOFTWARE\NVIDIA Corporation\Global\ShadowPlay\NVSPCAPS" -Name "ShowIndicator" -Value 0 -Type DWord
        $changes.Add("Reduced NVIDIA overlay footprint (fully disable in GeForce Experience > Settings > General if you don't use it)")
    }
    $discordSettings = "$env:APPDATA\discord\settings.json"
    if (Test-Path $discordSettings) {
        $changes.Add("Discord detected - manually turn off 'Enable in-game overlay' in Discord Settings > Activity Overlay for the biggest overlay-related win")
    }
} catch {
    Write-Host "Skipped overlay check: $_" -ForegroundColor DarkYellow
    $skipped.Add("Overlay footprint check")
}

# 5. Low-latency TCP tweak (disable Nagle's algorithm)
try {
    $iface = Get-NetIPInterface -AddressFamily IPv4 | Where-Object { $_.ConnectionState -eq "Connected" } | Select-Object -First 1
    if ($iface) {
        $tcpPath = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$($iface.InterfaceGuid)"
        if (Test-Path $tcpPath) {
            Set-TunedRegValue -Path $tcpPath -Name "TcpAckFrequency" -Value 1 -Type DWord
            Set-TunedRegValue -Path $tcpPath -Name "TCPNoDelay" -Value 1 -Type DWord
            $changes.Add("Disabled Nagle's algorithm on your active network adapter")
        }
    }
} catch {
    Write-Host "Skipped network tweak: $_" -ForegroundColor DarkYellow
    $skipped.Add("Nagle's algorithm disable")
}

# 6. Games task scheduling priority + remove network throttling cap
try {
    $mmcssPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games"
    Set-TunedRegValue -Path $mmcssPath -Name "GPU Priority" -Value 8 -Type DWord
    Set-TunedRegValue -Path $mmcssPath -Name "Priority" -Value 6 -Type DWord
    Set-TunedRegValue -Path $mmcssPath -Name "Scheduling Category" -Value "High" -Type String
    Set-TunedRegValue -Path $mmcssPath -Name "SFIO Priority" -Value "High" -Type String
    Set-TunedRegValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" -Name "NetworkThrottlingIndex" -Value 0xFFFFFFFF -Type DWord
    $changes.Add("Set games to High scheduling priority and removed the network throttling cap in Windows' multimedia scheduler")
} catch {
    Write-Host "Skipped MMCSS/network throttling change: $_" -ForegroundColor DarkYellow
    $skipped.Add("Game scheduling priority / network throttling removal")
}

# 6b. Turn off Delivery Optimization's peer-to-peer uploading
try {
    Set-TunedRegValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" -Name "DODownloadMode" -Value 0 -Type DWord
    $changes.Add("Disabled Delivery Optimization peer-to-peer uploading")
} catch {
    Write-Host "Skipped Delivery Optimization change: $_" -ForegroundColor DarkYellow
    $skipped.Add("Delivery Optimization disable")
}

# 7. Auto High priority for Fortnite via Scheduled Task
try {
    $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument `
        "-WindowStyle Hidden -Command `"while(`$true){ `$p = Get-Process FortniteClient-Win64-Shipping -ErrorAction SilentlyContinue; if(`$p -and `$p.PriorityClass -ne 'High'){ `$p.PriorityClass = 'High' }; Start-Sleep -Seconds 5 }`""
    $trigger = New-ScheduledTaskTrigger -AtLogOn
    Register-ScheduledTask -TaskName "TUNED-FortnitePriority" -Action $action -Trigger $trigger -RunLevel Highest -Force -ErrorAction Stop | Out-Null
    $changes.Add("Set up automatic High priority for Fortnite on launch")
    $undoLines.Add("Unregister-ScheduledTask -TaskName 'TUNED-FortnitePriority' -Confirm:`$false -ErrorAction SilentlyContinue")
} catch {
    Write-Host "Skipped priority task setup: $_" -ForegroundColor DarkYellow
    $skipped.Add("Automatic Fortnite process priority")
}

# 8. RAM speed (XMP/DOCP) check - informational only
try {
    $mem = Get-CimInstance Win32_PhysicalMemory | Select-Object -First 1
    $currentSpeed = $mem.ConfiguredClockSpeed
    $ratedSpeed = $mem.Speed
    if ($ratedSpeed -and $currentSpeed -and ($currentSpeed -lt $ratedSpeed)) {
        $changes.Add("RAM is running at $currentSpeed MHz but is rated for $ratedSpeed MHz - enable XMP/DOCP in your BIOS for a free performance gain (can't be done from Windows)")
    } else {
        $changes.Add("RAM speed looks correctly configured ($currentSpeed MHz)")
    }
} catch {
    Write-Host "Could not check RAM speed on this system." -ForegroundColor DarkYellow
}

$elapsed = [math]::Round(((Get-Date) - $startTime).TotalSeconds)
Write-Host "`n== Done in $elapsed seconds. $($changes.Count) changes applied. ==" -ForegroundColor Yellow
foreach ($c in $changes) { Write-Host " - $c" }

if ($skipped.Count -gt 0) {
    Write-Host "`n$($skipped.Count) item(s) skipped on this system:" -ForegroundColor DarkYellow
    foreach ($s in $skipped) { Write-Host " - $s" }
}

# 9. Write the personal report and the precise undo script
try {
    $reportPath = Join-Path $PSScriptRoot "tuned-report.txt"
    $undoPath = Join-Path $PSScriptRoot "tuned-undo.ps1"
    $cpu = (Get-CimInstance Win32_Processor | Select-Object -First 1).Name
    $gpu = (Get-CimInstance Win32_VideoController | Select-Object -First 1).Name
    $os = (Get-CimInstance Win32_OperatingSystem).Caption

    $report = @()
    $report += "TUNED. - Personal Tune Report (script v$scriptVersion)"
    $report += "Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm') - run took $elapsed seconds"
    $report += ""
    $report += "-- Your system --"
    $report += "CPU: $cpu"
    $report += "GPU: $gpu"
    $report += "OS: $os"
    $report += ""
    $report += "-- Changes applied this run ($($changes.Count)) --"
    foreach ($c in $changes) { $report += " - $c" }
    if ($skipped.Count -gt 0) {
        $report += ""
        $report += "-- Skipped on this system ($($skipped.Count)) --"
        foreach ($s in $skipped) { $report += " - $s" }
    }
    $report += ""
    $report += "-- To undo --"
    $report += "Run TUNED.bat again and choose option 2 when prompted. It reverses every change above exactly."
    $report += ""
    $report += "-- Checking your results --"
    $report += "Press Ctrl+Shift+B in Fortnite to show the FPS/frametime counter. Check it before and"
    $report += "after a restart to see your own before/after numbers."
    $report -join "`r`n" | Out-File -FilePath $reportPath -Encoding UTF8

    $undo = @()
    $undo += "#Requires -RunAsAdministrator"
    $undo += "# TUNED. undo script - generated $(Get-Date -Format 'yyyy-MM-dd HH:mm') from script v$scriptVersion"
    $undo += "# Reverses every change the Full Tune Pack made on this specific run, back to its original value."
    $undo += "Write-Host 'Reversing TUNED changes...' -ForegroundColor Yellow"
    foreach ($line in $undoLines) { $undo += $line }
    $undo += "Write-Host 'Done. Restart your PC for everything to fully revert.' -ForegroundColor Green"
    $undo -join "`r`n" | Out-File -FilePath $undoPath -Encoding UTF8

    Write-Host "`nSaved: $reportPath" -ForegroundColor Cyan
    Write-Host "Saved: $undoPath" -ForegroundColor Cyan
    Write-Host "To undo later, just run TUNED.bat again and choose option 2." -ForegroundColor Cyan
} catch {
    Write-Host "Could not write the report/undo files: $_" -ForegroundColor DarkYellow
}

Stop-Transcript | Out-Null
Write-Host "`n(A full run log was also saved to: $logPath)" -ForegroundColor DarkGray
Write-Host "`nRestart your PC for all changes to fully apply." -ForegroundColor Green
Write-Host "`nThanks for picking up the Full Tune Pack - good luck out there." -ForegroundColor Yellow
