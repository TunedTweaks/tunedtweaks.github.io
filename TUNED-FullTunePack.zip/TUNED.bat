@echo off
title TUNED. Full Tune Pack

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting administrator permission - click Yes on the popup...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

if exist "%~dp0tuned-undo.ps1" (
    echo ============================================
    echo   TUNED.
    echo ============================================
    echo   1. Run the Full Tune Pack
    echo   2. Undo my previous tune
    echo ============================================
    set /p choice="Type 1 or 2, then press Enter: "
) else (
    set choice=1
)

if "%choice%"=="2" (
    echo.
    echo Reversing TUNED changes...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tuned-undo.ps1"
) else (
    echo.
    echo Starting the TUNED. Full Tune Pack...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0TUNED-optimize.ps1"
)

echo.
echo ============================================
echo Done. Press any key to close this window.
echo ============================================
pause >nul
